import { useState } from 'react'
import { generateLayouts } from '../utils/layoutEngine'

export default function LayoutPicker({ fields, barcodeCol, columnStyles, dimensions, onConfirm, onBack }) {
  const [selected, setSelected] = useState(null)
  const layouts = generateLayouts(fields, barcodeCol, columnStyles)

  // Use actual label aspect ratio when dimensions available, else default 90x65
  const vw = dimensions?.width || 90
  const vh = dimensions?.height || 65

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">Choose a layout</h2>
      <p className="text-sm text-gray-600">Select how your labels should look</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {layouts.map((layout) => (
          <div
            key={layout.id}
            onClick={() => setSelected(layout)}
            className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
              selected?.id === layout.id ? 'border-accent bg-orange-50 shadow-md' : 'border-gray-200 hover:border-gray-400'
            }`}
          >
            <h3 className="font-semibold mb-1">{layout.name}</h3>
            <p className="text-xs text-gray-500 mb-3">{layout.description}</p>

            {/* Mini SVG preview with correct aspect ratio */}
            <svg viewBox={`0 0 ${vw} ${vh}`} className="w-full border rounded bg-white" style={{ maxHeight: '160px', aspectRatio: `${vw}/${vh}` }}>
              <rect width={vw} height={vh} fill="white" />
              {layout.elements.map((el, i) => {
                if (el.type === 'text') {
                  const sx = vw / 90
                  const sy = vh / 65
                  return (
                    <text
                      key={i}
                      x={el.x * sx}
                      y={el.y * sy}
                      fontSize={Math.max(4, el.fontSize * 0.6 * Math.min(sx, sy))}
                      fontWeight={el.fontWeight}
                      fill={el.fontWeight === 'bold' ? '#1B2A4A' : '#666'}
                    >
                      {el.column.length > 8 ? el.column.slice(0, 7) + '…' : el.column}
                    </text>
                  )
                }
                if (el.type === 'barcode') {
                  const sx = vw / 90
                  const sy = vh / 65
                  const bx = el.x * sx
                  const by = el.y * sy
                  const bw = Math.max(10, el.width * sx)
                  const barCount = Math.max(6, Math.floor(bw / 2.5))
                  return (
                    <g key={i}>
                      {Array.from({ length: barCount }).map((_, j) => (
                        <rect
                          key={j}
                          x={bx + (j / barCount) * bw}
                          y={by}
                          width={Math.max(0.5, (bw / barCount) * 0.6)}
                          height={Math.min(30, 22 * sy)}
                          fill={j % 2 === 0 ? '#333' : '#ccc'}
                        />
                      ))}
                    </g>
                  )
                }
                return null
              })}
            </svg>
          </div>
        ))}
      </div>

      <div className="flex gap-3">
        <button onClick={onBack} className="px-6 py-2 border border-gray-300 rounded-lg font-medium hover:bg-gray-50 transition-colors">
          Back
        </button>
        <button
          onClick={() => selected && onConfirm(selected)}
          disabled={!selected}
          className={`px-6 py-2 rounded-lg font-medium transition-colors ${
            !selected ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-accent text-white hover:bg-[#d96c1e]'
          }`}
        >
          Next: Generate PDF
        </button>
      </div>
    </div>
  )
}
