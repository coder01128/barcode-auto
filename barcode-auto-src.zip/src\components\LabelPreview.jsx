import { useEffect, useRef } from 'react'
import JsBarcode from 'jsbarcode'
import { scaleLayoutToLabel, autoScaleContent } from '../utils/layoutEngine'

export default function LabelPreview({ layout, dimensions }) {
  if (!layout || !dimensions) return null

  // Scale layout to actual label dimensions
  const scaled = scaleLayoutToLabel(layout, dimensions)
  const { elements } = autoScaleContent(scaled, dimensions)

  const scale = Math.min(200 / dimensions.width, 200 / dimensions.height, 2)
  const svgW = dimensions.width * scale
  const svgH = dimensions.height * scale

  return (
    <div className="bg-white rounded-lg border p-4">
      <h3 className="font-semibold mb-2">Label preview</h3>
      <svg viewBox={`0 0 ${dimensions.width} ${dimensions.height}`} width={svgW} height={svgH} className="border mx-auto bg-white">
        <rect width={dimensions.width} height={dimensions.height} fill="white" />
        {elements.map((el, i) => {
          if (el.type === 'text') {
            return (
              <text
                key={i}
                x={el.x}
                y={el.y + el.fontSize * 0.35}
                fontSize={el.fontSize * 0.35}
                fontWeight={el.fontWeight}
                fill="#1B2A4A"
              >
                {el.column}
              </text>
            )
          }
          if (el.type === 'barcode') {
            return <BarcodeElement key={i} el={el} />
          }
          return null
        })}
      </svg>
    </div>
  )
}

function BarcodeElement({ el }) {
  const svgRef = useRef(null)

  useEffect(() => {
    if (svgRef.current) {
      try {
        JsBarcode(svgRef.current, '1234567890128', {
          format: 'CODE128',
          width: 1.5,
          height: el.height - 6,
          displayValue: true,
          fontSize: 10,
          margin: 2,
        })
      } catch {
        // JsBarcode error — nested SVG stays empty, harmless
      }
    }
  }, [el.height, el.width])

  return (
    <svg
      ref={svgRef}
      x={el.x}
      y={el.y}
      width={el.width}
      height={el.height}
    />
  )
}
