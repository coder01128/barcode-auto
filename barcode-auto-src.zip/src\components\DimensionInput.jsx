import { useState } from 'react'

const PRESETS = [
  { label: '40×30mm', w: 40, h: 30, gap: 3 },
  { label: '50×25mm', w: 50, h: 25, gap: 3 },
  { label: '50×30mm', w: 50, h: 30, gap: 3 },
  { label: '60×40mm', w: 60, h: 40, gap: 5 },
  { label: '100×150mm (4×6in)', w: 100, h: 150, gap: 5 },
  { label: 'Shipping 100×70mm', w: 100, h: 70, gap: 5 },
]

export default function DimensionInput({ onConfirm, onBack }) {
  const [width, setWidth] = useState(40)
  const [height, setHeight] = useState(30)
  const [gap, setGap] = useState(3)

  function handlePreset(p) {
    setWidth(p.w)
    setHeight(p.h)
    setGap(p.gap)
  }

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">Label dimensions</h2>

      <div className="bg-white rounded-lg border p-4">
        <h3 className="font-semibold mb-3 text-sm text-gray-600">Common sizes</h3>
        <div className="flex flex-wrap gap-2">
          {PRESETS.map((p) => (
            <button
              key={p.label}
              onClick={() => handlePreset(p)}
              className="px-3 py-1.5 text-sm border rounded-lg hover:bg-gray-50 transition-colors"
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-lg border p-4">
        <h3 className="font-semibold mb-4">Enter dimensions (mm)</h3>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Width (mm)</label>
            <p className="text-[10px] text-gray-400 mb-1 leading-tight">measured across the roll</p>
            <input
              type="number"
              min={10}
              max={200}
              value={width}
              onChange={(e) => setWidth(Number(e.target.value))}
              className="w-full p-2 border rounded-lg text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Height (mm)</label>
            <p className="text-[10px] text-gray-400 mb-1 leading-tight">measured along feed direction</p>
            <input
              type="number"
              min={10}
              max={300}
              value={height}
              onChange={(e) => setHeight(Number(e.target.value))}
              className="w-full p-2 border rounded-lg text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Gap</label>
            <input
              type="number"
              min={0}
              max={20}
              value={gap}
              onChange={(e) => setGap(Number(e.target.value))}
              className="w-full p-2 border rounded-lg text-sm"
            />
          </div>
        </div>
      </div>

      {/* Roll direction diagram + Live SVG preview */}
      <div className="bg-white rounded-lg border p-4">
        <h3 className="font-semibold mb-3 text-sm text-gray-600">Preview</h3>

        {/* Roll direction reference */}
        <div className="flex justify-center mb-4">
          <svg width="200" height="70" viewBox="0 0 200 70" className="text-gray-400">
            {/* Roll body (circle) on left */}
            <circle cx="35" cy="35" r="30" fill="#e5e7eb" stroke="#9ca3af" strokeWidth="1.5" />
            <circle cx="35" cy="35" r="18" fill="#d1d5db" stroke="#9ca3af" strokeWidth="1" />
            <text x="35" y="38" textAnchor="middle" fontSize="8" fill="#6b7280">roll</text>

            {/* Label strip extending from roll */}
            <rect x="62" y="15" width="100" height="40" fill="#f0f4ff" stroke="#1B2A4A" strokeWidth="1.5" rx="2" />
            <text x="112" y="28" textAnchor="middle" fontSize="7" fill="#1B2A4A">label</text>
            <text x="112" y="42" textAnchor="middle" fontSize="6" fill="#6b7280">{width}×{height}mm</text>

            {/* Width arrow (across roll) */}
            <line x1="62" y1="7" x2="162" y2="7" stroke="#E87A2D" strokeWidth="1.5" markerEnd="url(#arrowW)" />
            <line x1="162" y1="7" x2="62" y2="7" stroke="#E87A2D" strokeWidth="1.5" markerEnd="url(#arrowW)" />
            <text x="112" y="5" textAnchor="middle" fontSize="7" fill="#E87A2D" fontWeight="bold">← Width →</text>

            {/* Height arrow (feed direction) */}
            <line x1="170" y1="15" x2="170" y2="55" stroke="#E87A2D" strokeWidth="1.5" />
            <text x="185" y="38" textAnchor="middle" fontSize="7" fill="#E87A2D" fontWeight="bold" transform="rotate(90, 185, 38)">← Feed →</text>

            {/* Feed direction arrow below */}
            <line x1="65" y1="62" x2="155" y2="62" stroke="#9ca3af" strokeWidth="1" strokeDasharray="3 2" />
            <polygon points="155,58 162,62 155,66" fill="#9ca3af" />

            <defs>
              <marker id="arrowW" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="4" markerHeight="4" orient="auto-start-reverse">
                <path d="M 0 0 L 10 5 L 0 10 z" fill="#E87A2D" />
              </marker>
            </defs>
          </svg>
        </div>

        {/* Live preview */}
        <div className="flex items-end justify-center gap-1">
          <svg width={Math.min(width * 3, 200)} height={Math.min(height * 3, 200)} className="border-2 border-primary rounded">
            <rect width="100%" height="100%" fill="#f0f4ff" />
            <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle" fontSize="10" fill="#1B2A4A">
              {width}×{height}mm label
            </text>
          </svg>
          {gap > 0 && (
            <div
              className="bg-gray-200 rounded-sm flex items-center justify-center"
              style={{ width: `${Math.min(gap * 3, 30)}px`, height: `${Math.min(height * 3, 200)}px`, minWidth: '4px' }}
            >
              <span className="text-[8px] text-gray-500 rotate-[-90deg] whitespace-nowrap">{gap}mm</span>
            </div>
          )}
          <svg width={Math.min(width * 3, 200)} height={Math.min(height * 3, 200)} className="border-2 border-dashed border-gray-400 rounded">
            <rect width="100%" height="100%" fill="#fafafa" />
            <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle" fontSize="10" fill="#999">
              next label
            </text>
          </svg>
        </div>
        <p className="text-xs text-gray-500 mt-2 text-center">
          Pitch = {width}mm × {height + gap}mm (label + gap).{' '}
          Width is across the roll, height is along the feed direction.
        </p>
      </div>

      <div className="flex gap-3">
        <button onClick={onBack} className="px-6 py-2 border border-gray-300 rounded-lg font-medium hover:bg-gray-50 transition-colors">
          Back
        </button>
        <button
          onClick={() => onConfirm({ width, height, gap })}
          className="px-6 py-2 bg-accent text-white rounded-lg font-medium hover:bg-[#d96c1e] transition-colors"
        >
          Next: Choose layout
        </button>
      </div>
    </div>
  )
}
