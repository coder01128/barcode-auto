import { useState, useEffect } from 'react'
import { BARCODE_TYPES, suggestBarcodeFormat } from '../utils/barcodeUtils'

const QTY_NAMES = ['qty', 'quantity']

export default function ColumnSelector({ headers, rows, onConfirm, onBack }) {
  const [selected, setSelected] = useState({})
  const [barcodeCol, setBarcodeCol] = useState('')
  const [barcodeType, setBarcodeType] = useState('ean13')
  const [columnStyles, setColumnStyles] = useState({})
  const [useQty, setUseQty] = useState(true)

  const qtyCol = headers.find((h) => QTY_NAMES.includes(h.toLowerCase()))

  useEffect(() => {
    if (headers.length > 0) {
      const init = {}
      headers.forEach((h) => { init[h] = true })
      setSelected(init)
      setBarcodeCol(headers[0])

      const sampleValues = rows.slice(0, 10).map((r) => String(r[headers[0]] ?? '').replace(/\s/g, ''))
      const digitCounts = sampleValues.filter(Boolean).map((v) => v.length)
      if (digitCounts.length > 0) {
        const avgLen = Math.round(digitCounts.reduce((a, b) => a + b, 0) / digitCounts.length)
        setBarcodeType(suggestBarcodeFormat(avgLen))
      }
    }
  }, [headers, rows])

  function toggleColumn(h) {
    setSelected((prev) => ({ ...prev, [h]: !prev[h] }))
  }

  function toggleStyle(col, style) {
    setColumnStyles((prev) => {
      const current = prev[col] || {}
      return { ...prev, [col]: { ...current, [style]: !current[style] } }
    })
  }

  const selectedCount = Object.values(selected).filter(Boolean).length

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">Choose label columns</h2>

      <div className="bg-white rounded-lg border p-4">
        <h3 className="font-semibold mb-3">Columns in your file</h3>
        <div className="flex flex-wrap gap-2">
          {headers.map((h) => (
            <button
              key={h}
              onClick={() => toggleColumn(h)}
              className={`px-4 py-2 rounded-full text-sm font-medium border transition-colors ${
                selected[h] ? 'bg-primary text-white border-primary' : 'bg-white text-gray-700 border-gray-300 hover:border-gray-400'
              }`}
            >
              {h}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-lg border p-4">
        <h3 className="font-semibold mb-3">Which column has the barcode number?</h3>
        <select
          value={barcodeCol}
          onChange={(e) => setBarcodeCol(e.target.value)}
          className="w-full p-2 border rounded-lg text-sm"
        >
          {headers.filter((h) => selected[h]).map((h) => (
            <option key={h} value={h}>{h}</option>
          ))}
        </select>
      </div>

      <div className="bg-white rounded-lg border p-4">
        <h3 className="font-semibold mb-3">Barcode format</h3>
        <select
          value={barcodeType}
          onChange={(e) => setBarcodeType(e.target.value)}
          className="w-full p-2 border rounded-lg text-sm"
        >
          {BARCODE_TYPES.map((bt) => (
            <option key={bt.id} value={bt.id}>{bt.name}</option>
          ))}
        </select>
      </div>

      {qtyCol && (
        <div className="bg-white rounded-lg border p-4">
          <h3 className="font-semibold mb-2">Quantity column detected</h3>
          <p className="text-xs text-gray-500 mb-2">
            Found "{qtyCol}" column — use it to print multiple copies per item.
          </p>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={useQty}
              onChange={(e) => setUseQty(e.target.checked)}
              className="rounded"
            />
            Use QTY column to print multiple copies per item
          </label>
        </div>
      )}

      {selectedCount > 0 && (
        <div className="bg-white rounded-lg border p-4">
          <h3 className="font-semibold mb-3">Text style (optional)</h3>
          <p className="text-xs text-gray-500 mb-2">Make a column bold or large (e.g. price)</p>
          <div className="space-y-2">
            {headers.filter((h) => selected[h] && h !== barcodeCol).map((h) => (
              <div key={h} className="flex items-center justify-between text-sm">
                <span>{h}</span>
                <div className="flex gap-2">
                  <label className="flex items-center gap-1 text-xs">
                    <input type="checkbox" checked={columnStyles[h]?.isBold || false} onChange={() => toggleStyle(h, 'isBold')} />
                    Bold
                  </label>
                  <label className="flex items-center gap-1 text-xs">
                    <input type="checkbox" checked={columnStyles[h]?.isLarge || false} onChange={() => toggleStyle(h, 'isLarge')} />
                    Large
                  </label>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex gap-3">
        <button onClick={onBack} className="px-6 py-2 border border-gray-300 rounded-lg font-medium hover:bg-gray-50 transition-colors">
          Back
        </button>
        <button
          onClick={() => onConfirm({ selectedCols: headers.filter((h) => selected[h]), barcodeCol, barcodeType, columnStyles, qtyCol: useQty ? qtyCol : null, useQty })}
          disabled={selectedCount < 2}
          className={`px-6 py-2 rounded-lg font-medium transition-colors ${
            selectedCount < 2 ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-accent text-white hover:bg-[#d96c1e]'
          }`}
        >
          Next: Set label size ({selectedCount} columns)
        </button>
      </div>
    </div>
  )
}
