import { jsPDF } from 'jspdf'
import JsBarcode from 'jsbarcode'
import { scaleLayoutToLabel, autoScaleContent } from './layoutEngine'

export function generateLabelPdf({ rows, barcodeCol, barcodeType, layout, dimensions, qtyCol, useQty }) {
  const { width, height, gap } = dimensions
  const totalPitch = height + gap

  // Scale layout to actual label dimensions
  const scaledLayout = scaleLayoutToLabel(layout, dimensions)
  const { elements, fits } = autoScaleContent(scaledLayout, dimensions)

  const doc = new jsPDF({
    orientation: width >= height ? 'landscape' : 'portrait',
    unit: 'mm',
    format: [width, totalPitch],
  })

  // Expand rows by QTY if enabled
  let expandedRows = rows
  if (qtyCol && useQty) {
    expandedRows = []
    rows.forEach((row) => {
      const qty = parseInt(row[qtyCol], 10) || 1
      for (let i = 0; i < qty; i++) {
        expandedRows.push(row)
      }
    })
  }

  // Blank calibration page (page 1)
  doc.addPage([width, totalPitch])

  // Label pages
  expandedRows.forEach((row) => {
    doc.addPage([width, totalPitch])

    elements.forEach((el) => {
      if (el.type === 'text') {
        const text = String(row[el.column] ?? '')
        doc.setFontSize(el.fontSize)
        doc.setFont('helvetica', el.fontWeight === 'bold' ? 'bold' : 'normal')
        const lines = doc.splitTextToSize(text, el.width)
        doc.text(lines, el.x, el.y + el.fontSize * 0.35)
      } else if (el.type === 'barcode') {
        const barcodeValue = String(row[barcodeCol] ?? '')
        if (barcodeValue) {
          try {
            const canvas = document.createElement('canvas')
            JsBarcode(canvas, barcodeValue, {
              format: getJsBarcodeFormat(barcodeType),
              width: 1.5,
              height: el.height - 4,
              displayValue: true,
              fontSize: 10,
              margin: 2,
            })
            const dataUrl = canvas.toDataURL('image/png')
            doc.addImage(dataUrl, 'PNG', el.x, el.y, el.width, el.height)
          } catch (e) {
            doc.setFontSize(10)
            doc.text(barcodeValue, el.x, el.y + 15)
          }
        }
      }
    })
  })

  // Remove empty page created by constructor (page 1), calibration stays as page 1
  if (doc.getNumberOfPages() > 1) {
    doc.deletePage(1)
  }

  return { doc, labelCount: expandedRows.length, rowCount: rows.length, fits }
}

function getJsBarcodeFormat(format) {
  const map = {
    ean13: 'EAN13',
    upca: 'UPC-A',
    code128: 'CODE128',
    code39: 'CODE39',
    qrcode: 'CODE128',
  }
  return map[format] || 'CODE128'
}
