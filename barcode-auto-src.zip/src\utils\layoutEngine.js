const VIRTUAL_W = 90
const VIRTUAL_H = 65
const SAFE_ZONE_MM = 3

function getStyle(col, styles) {
  const s = styles?.[col] || {}
  return { isBold: s.isBold || false, isLarge: s.isLarge || false }
}

export function scaleLayoutToLabel(layout, dimensions) {
  const { width: labelW, height: labelH } = dimensions
  const margin = SAFE_ZONE_MM
  const availW = labelW - margin * 2
  const availH = labelH - margin * 2

  if (availW <= 0 || availH <= 0) return layout

  const scaleX = availW / VIRTUAL_W
  const scaleY = availH / VIRTUAL_H

  return {
    ...layout,
    elements: layout.elements.map((el) => ({
      ...el,
      x: margin + (el.x / VIRTUAL_W) * availW,
      y: margin + (el.y / VIRTUAL_H) * availH,
      width: el.width * scaleX,
      height: el.height * scaleY,
      fontSize: Math.max(5, el.fontSize * scaleY),
    })),
  }
}

const PT_TO_MM = 0.3528

function textBottomMm(el) {
  // fontSize in pt → line height in mm (~1.4x line height)
  return el.y + el.fontSize * PT_TO_MM * 1.4
}

export function autoScaleContent(scaledLayout, dimensions) {
  const { height: labelH } = dimensions
  const margin = SAFE_ZONE_MM
  const maxBottom = labelH - margin

  let elements = scaledLayout.elements.map((e) => ({ ...e }))

  // Find lowest point of all content
  let lowest = 0
  elements.forEach((el) => {
    if (el.type === 'barcode') {
      lowest = Math.max(lowest, el.y + el.height)
    } else if (el.type === 'text') {
      lowest = Math.max(lowest, textBottomMm(el))
    }
  })

  if (lowest <= maxBottom) return { elements, fits: true }

  // Scale down to fit
  const scale = maxBottom / lowest

  elements.forEach((el) => {
    el.y = margin + (el.y - margin) * scale
    if (el.type === 'barcode') {
      el.height = Math.max(6, el.height * scale)
    } else if (el.type === 'text') {
      el.fontSize = Math.max(5, el.fontSize * scale)
    }
    el.x = margin + (el.x - margin) * scale
    el.width = Math.max(10, el.width * scale)
  })

  // Final fit check
  lowest = 0
  elements.forEach((el) => {
    if (el.type === 'barcode') {
      lowest = Math.max(lowest, el.y + el.height)
    } else if (el.type === 'text') {
      lowest = Math.max(lowest, textBottomMm(el))
    }
  })

  return { elements, fits: lowest <= maxBottom + 1 }
}

const LAYOUT_TEMPLATES = [
  {
    id: 'stacked',
    name: 'Stacked',
    description: 'Barcode bottom, text stacked above',
    key: 'stacked',
  },
  {
    id: 'side-by-side',
    name: 'Side by Side',
    description: 'Barcode right, text left',
    key: 'side-by-side',
  },
  {
    id: 'compact',
    name: 'Compact',
    description: 'Minimal: barcode + 2 key fields',
    key: 'compact',
  },
  {
    id: 'price-tag',
    name: 'Price Tag',
    description: 'Barcode top, price prominent, details below',
    key: 'price-tag',
  },
]

function generateStacked(fields, barcodeCol, columnStyles) {
  const elements = []
  fields.forEach((f) => {
    if (f === barcodeCol) return
    const { isBold, isLarge } = getStyle(f, columnStyles)
    elements.push({
      type: 'text',
      column: f,
      x: 5,
      y: elements.length * 6 + 5,
      fontSize: isLarge ? 14 : isBold ? 11 : 10,
      fontWeight: isBold ? 'bold' : 'normal',
      width: 80,
      align: 'left',
    })
  })
  elements.push({
    type: 'barcode',
    column: barcodeCol,
    x: 5,
    y: 55,
    width: 80,
    height: 25,
  })
  return { elements, id: 'stacked' }
}

function generateSideBySide(fields, barcodeCol, columnStyles) {
  const elements = []
  const leftFields = fields.filter((f) => f !== barcodeCol)
  leftFields.forEach((f, i) => {
    const { isBold, isLarge } = getStyle(f, columnStyles)
    elements.push({
      type: 'text',
      column: f,
      x: 5,
      y: i * 7 + 5,
      fontSize: isLarge ? 13 : isBold ? 11 : 10,
      fontWeight: isBold ? 'bold' : 'normal',
      width: 45,
      align: 'left',
    })
  })
  elements.push({
    type: 'barcode',
    column: barcodeCol,
    x: 52,
    y: 10,
    width: 40,
    height: 30,
  })
  return { elements, id: 'side-by-side' }
}

function generateCompact(fields, barcodeCol, columnStyles) {
  const elements = []
  const nonBarcode = fields.filter((f) => f !== barcodeCol)
  const keyFields = nonBarcode.slice(0, 2)
  keyFields.forEach((f, i) => {
    const { isBold } = getStyle(f, columnStyles)
    elements.push({
      type: 'text',
      column: f,
      x: 5,
      y: i * 7 + 5,
      fontSize: isBold ? 13 : 11,
      fontWeight: isBold ? 'bold' : 'normal',
      width: 80,
      align: 'left',
    })
  })
  elements.push({
    type: 'barcode',
    column: barcodeCol,
    x: 5,
    y: 40,
    width: 80,
    height: 30,
  })
  return { elements, id: 'compact' }
}

function generatePriceTag(fields, barcodeCol, columnStyles) {
  const elements = []
  elements.push({
    type: 'barcode',
    column: barcodeCol,
    x: 10,
    y: 3,
    width: 70,
    height: 22,
  })
  const remaining = fields.filter((f) => f !== barcodeCol)
  remaining.forEach((f, i) => {
    const { isBold, isLarge } = getStyle(f, columnStyles)
    elements.push({
      type: 'text',
      column: f,
      x: 5,
      y: isLarge ? 28 + i * 8 + 10 : 28 + i * 7 + 10,
      fontSize: isLarge ? 18 : isBold ? 12 : 10,
      fontWeight: isBold ? 'bold' : 'normal',
      width: 80,
      align: 'center',
    })
  })
  return { elements, id: 'price-tag' }
}

const GENERATORS = {
  stacked: generateStacked,
  'side-by-side': generateSideBySide,
  compact: generateCompact,
  'price-tag': generatePriceTag,
}

export function generateLayouts(fields, barcodeCol, columnStyles = {}) {
  return LAYOUT_TEMPLATES.map((t) => {
    const fn = GENERATORS[t.key]
    const { elements } = fn(fields, barcodeCol, columnStyles)
    return { id: t.id, name: t.name, description: t.description, elements }
  })
}
